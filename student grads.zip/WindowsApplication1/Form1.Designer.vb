﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblav1 = New System.Windows.Forms.Label()
        Me.lblav2 = New System.Windows.Forms.Label()
        Me.lblav3 = New System.Windows.Forms.Label()
        Me.lblav4 = New System.Windows.Forms.Label()
        Me.lblav5 = New System.Windows.Forms.Label()
        Me.lblav6 = New System.Windows.Forms.Label()
        Me.tbx1_1 = New System.Windows.Forms.TextBox()
        Me.tbx2_1 = New System.Windows.Forms.TextBox()
        Me.tbx3_1 = New System.Windows.Forms.TextBox()
        Me.tbx4_1 = New System.Windows.Forms.TextBox()
        Me.tbx5_1 = New System.Windows.Forms.TextBox()
        Me.tbx6_1 = New System.Windows.Forms.TextBox()
        Me.tbx1_2 = New System.Windows.Forms.TextBox()
        Me.tbx1_3 = New System.Windows.Forms.TextBox()
        Me.tbx1_4 = New System.Windows.Forms.TextBox()
        Me.tbx1_5 = New System.Windows.Forms.TextBox()
        Me.tbx6_2 = New System.Windows.Forms.TextBox()
        Me.tbx5_2 = New System.Windows.Forms.TextBox()
        Me.tbx4_2 = New System.Windows.Forms.TextBox()
        Me.tbx3_2 = New System.Windows.Forms.TextBox()
        Me.tbx2_2 = New System.Windows.Forms.TextBox()
        Me.tbx6_3 = New System.Windows.Forms.TextBox()
        Me.tbx5_3 = New System.Windows.Forms.TextBox()
        Me.tbx4_3 = New System.Windows.Forms.TextBox()
        Me.tbx3_3 = New System.Windows.Forms.TextBox()
        Me.tbx2_3 = New System.Windows.Forms.TextBox()
        Me.tbx6_4 = New System.Windows.Forms.TextBox()
        Me.tbx5_4 = New System.Windows.Forms.TextBox()
        Me.tbx4_4 = New System.Windows.Forms.TextBox()
        Me.tbx3_4 = New System.Windows.Forms.TextBox()
        Me.tbx2_4 = New System.Windows.Forms.TextBox()
        Me.tbx6_5 = New System.Windows.Forms.TextBox()
        Me.tbx5_5 = New System.Windows.Forms.TextBox()
        Me.tbx4_5 = New System.Windows.Forms.TextBox()
        Me.tbx3_5 = New System.Windows.Forms.TextBox()
        Me.tbx2_5 = New System.Windows.Forms.TextBox()
        Me.tbxn1 = New System.Windows.Forms.TextBox()
        Me.tbxn2 = New System.Windows.Forms.TextBox()
        Me.tbxn3 = New System.Windows.Forms.TextBox()
        Me.tbxn4 = New System.Windows.Forms.TextBox()
        Me.tbxn5 = New System.Windows.Forms.TextBox()
        Me.tbxn6 = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PrintReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GroupBox1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.tbxn6)
        Me.GroupBox1.Controls.Add(Me.tbxn5)
        Me.GroupBox1.Controls.Add(Me.tbxn4)
        Me.GroupBox1.Controls.Add(Me.tbxn3)
        Me.GroupBox1.Controls.Add(Me.tbxn2)
        Me.GroupBox1.Controls.Add(Me.tbxn1)
        Me.GroupBox1.Controls.Add(Me.tbx6_5)
        Me.GroupBox1.Controls.Add(Me.tbx5_5)
        Me.GroupBox1.Controls.Add(Me.tbx4_5)
        Me.GroupBox1.Controls.Add(Me.tbx3_5)
        Me.GroupBox1.Controls.Add(Me.tbx2_5)
        Me.GroupBox1.Controls.Add(Me.tbx6_4)
        Me.GroupBox1.Controls.Add(Me.tbx5_4)
        Me.GroupBox1.Controls.Add(Me.tbx4_4)
        Me.GroupBox1.Controls.Add(Me.tbx3_4)
        Me.GroupBox1.Controls.Add(Me.tbx2_4)
        Me.GroupBox1.Controls.Add(Me.tbx6_3)
        Me.GroupBox1.Controls.Add(Me.tbx5_3)
        Me.GroupBox1.Controls.Add(Me.tbx4_3)
        Me.GroupBox1.Controls.Add(Me.tbx3_3)
        Me.GroupBox1.Controls.Add(Me.tbx2_3)
        Me.GroupBox1.Controls.Add(Me.tbx6_2)
        Me.GroupBox1.Controls.Add(Me.tbx5_2)
        Me.GroupBox1.Controls.Add(Me.tbx4_2)
        Me.GroupBox1.Controls.Add(Me.tbx3_2)
        Me.GroupBox1.Controls.Add(Me.tbx2_2)
        Me.GroupBox1.Controls.Add(Me.tbx1_5)
        Me.GroupBox1.Controls.Add(Me.tbx1_4)
        Me.GroupBox1.Controls.Add(Me.tbx1_3)
        Me.GroupBox1.Controls.Add(Me.tbx1_2)
        Me.GroupBox1.Controls.Add(Me.tbx6_1)
        Me.GroupBox1.Controls.Add(Me.tbx5_1)
        Me.GroupBox1.Controls.Add(Me.tbx4_1)
        Me.GroupBox1.Controls.Add(Me.tbx3_1)
        Me.GroupBox1.Controls.Add(Me.tbx2_1)
        Me.GroupBox1.Controls.Add(Me.tbx1_1)
        Me.GroupBox1.Controls.Add(Me.lblav6)
        Me.GroupBox1.Controls.Add(Me.lblav5)
        Me.GroupBox1.Controls.Add(Me.lblav4)
        Me.GroupBox1.Controls.Add(Me.lblav3)
        Me.GroupBox1.Controls.Add(Me.lblav2)
        Me.GroupBox1.Controls.Add(Me.lblav1)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(13, 44)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(442, 205)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "GroupBox1"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(7, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(35, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Name"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(248, 21)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(41, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Grades"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(373, 20)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(47, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Average"
        '
        'lblav1
        '
        Me.lblav1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblav1.Location = New System.Drawing.Point(378, 38)
        Me.lblav1.Name = "lblav1"
        Me.lblav1.Size = New System.Drawing.Size(36, 20)
        Me.lblav1.TabIndex = 3
        Me.lblav1.Text = "Label4"
        '
        'lblav2
        '
        Me.lblav2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblav2.Location = New System.Drawing.Point(378, 65)
        Me.lblav2.Name = "lblav2"
        Me.lblav2.Size = New System.Drawing.Size(36, 20)
        Me.lblav2.TabIndex = 4
        Me.lblav2.Text = "Label5"
        '
        'lblav3
        '
        Me.lblav3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblav3.Location = New System.Drawing.Point(378, 91)
        Me.lblav3.Name = "lblav3"
        Me.lblav3.Size = New System.Drawing.Size(36, 20)
        Me.lblav3.TabIndex = 5
        Me.lblav3.Text = "Label6"
        '
        'lblav4
        '
        Me.lblav4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblav4.Location = New System.Drawing.Point(378, 117)
        Me.lblav4.Name = "lblav4"
        Me.lblav4.Size = New System.Drawing.Size(36, 20)
        Me.lblav4.TabIndex = 6
        Me.lblav4.Text = "Label7"
        '
        'lblav5
        '
        Me.lblav5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblav5.Location = New System.Drawing.Point(378, 143)
        Me.lblav5.Name = "lblav5"
        Me.lblav5.Size = New System.Drawing.Size(36, 20)
        Me.lblav5.TabIndex = 7
        Me.lblav5.Text = "Label8"
        '
        'lblav6
        '
        Me.lblav6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblav6.Location = New System.Drawing.Point(378, 169)
        Me.lblav6.Name = "lblav6"
        Me.lblav6.Size = New System.Drawing.Size(36, 20)
        Me.lblav6.TabIndex = 8
        Me.lblav6.Text = "Label9"
        '
        'tbx1_1
        '
        Me.tbx1_1.Location = New System.Drawing.Point(193, 38)
        Me.tbx1_1.Name = "tbx1_1"
        Me.tbx1_1.Size = New System.Drawing.Size(29, 20)
        Me.tbx1_1.TabIndex = 9
        '
        'tbx2_1
        '
        Me.tbx2_1.Location = New System.Drawing.Point(193, 65)
        Me.tbx2_1.Name = "tbx2_1"
        Me.tbx2_1.Size = New System.Drawing.Size(29, 20)
        Me.tbx2_1.TabIndex = 10
        '
        'tbx3_1
        '
        Me.tbx3_1.Location = New System.Drawing.Point(193, 91)
        Me.tbx3_1.Name = "tbx3_1"
        Me.tbx3_1.Size = New System.Drawing.Size(29, 20)
        Me.tbx3_1.TabIndex = 11
        '
        'tbx4_1
        '
        Me.tbx4_1.Location = New System.Drawing.Point(193, 117)
        Me.tbx4_1.Name = "tbx4_1"
        Me.tbx4_1.Size = New System.Drawing.Size(29, 20)
        Me.tbx4_1.TabIndex = 12
        '
        'tbx5_1
        '
        Me.tbx5_1.Location = New System.Drawing.Point(193, 143)
        Me.tbx5_1.Name = "tbx5_1"
        Me.tbx5_1.Size = New System.Drawing.Size(29, 20)
        Me.tbx5_1.TabIndex = 13
        '
        'tbx6_1
        '
        Me.tbx6_1.Location = New System.Drawing.Point(193, 169)
        Me.tbx6_1.Name = "tbx6_1"
        Me.tbx6_1.Size = New System.Drawing.Size(29, 20)
        Me.tbx6_1.TabIndex = 14
        '
        'tbx1_2
        '
        Me.tbx1_2.Location = New System.Drawing.Point(228, 38)
        Me.tbx1_2.Name = "tbx1_2"
        Me.tbx1_2.Size = New System.Drawing.Size(29, 20)
        Me.tbx1_2.TabIndex = 15
        '
        'tbx1_3
        '
        Me.tbx1_3.Location = New System.Drawing.Point(263, 38)
        Me.tbx1_3.Name = "tbx1_3"
        Me.tbx1_3.Size = New System.Drawing.Size(29, 20)
        Me.tbx1_3.TabIndex = 21
        '
        'tbx1_4
        '
        Me.tbx1_4.Location = New System.Drawing.Point(298, 38)
        Me.tbx1_4.Name = "tbx1_4"
        Me.tbx1_4.Size = New System.Drawing.Size(29, 20)
        Me.tbx1_4.TabIndex = 27
        '
        'tbx1_5
        '
        Me.tbx1_5.Location = New System.Drawing.Point(333, 38)
        Me.tbx1_5.Name = "tbx1_5"
        Me.tbx1_5.Size = New System.Drawing.Size(29, 20)
        Me.tbx1_5.TabIndex = 33
        '
        'tbx6_2
        '
        Me.tbx6_2.Location = New System.Drawing.Point(228, 169)
        Me.tbx6_2.Name = "tbx6_2"
        Me.tbx6_2.Size = New System.Drawing.Size(29, 20)
        Me.tbx6_2.TabIndex = 38
        '
        'tbx5_2
        '
        Me.tbx5_2.Location = New System.Drawing.Point(228, 143)
        Me.tbx5_2.Name = "tbx5_2"
        Me.tbx5_2.Size = New System.Drawing.Size(29, 20)
        Me.tbx5_2.TabIndex = 37
        '
        'tbx4_2
        '
        Me.tbx4_2.Location = New System.Drawing.Point(228, 117)
        Me.tbx4_2.Name = "tbx4_2"
        Me.tbx4_2.Size = New System.Drawing.Size(29, 20)
        Me.tbx4_2.TabIndex = 36
        '
        'tbx3_2
        '
        Me.tbx3_2.Location = New System.Drawing.Point(228, 91)
        Me.tbx3_2.Name = "tbx3_2"
        Me.tbx3_2.Size = New System.Drawing.Size(29, 20)
        Me.tbx3_2.TabIndex = 35
        '
        'tbx2_2
        '
        Me.tbx2_2.Location = New System.Drawing.Point(228, 65)
        Me.tbx2_2.Name = "tbx2_2"
        Me.tbx2_2.Size = New System.Drawing.Size(29, 20)
        Me.tbx2_2.TabIndex = 34
        '
        'tbx6_3
        '
        Me.tbx6_3.Location = New System.Drawing.Point(263, 169)
        Me.tbx6_3.Name = "tbx6_3"
        Me.tbx6_3.Size = New System.Drawing.Size(29, 20)
        Me.tbx6_3.TabIndex = 43
        '
        'tbx5_3
        '
        Me.tbx5_3.Location = New System.Drawing.Point(263, 143)
        Me.tbx5_3.Name = "tbx5_3"
        Me.tbx5_3.Size = New System.Drawing.Size(29, 20)
        Me.tbx5_3.TabIndex = 42
        '
        'tbx4_3
        '
        Me.tbx4_3.Location = New System.Drawing.Point(263, 117)
        Me.tbx4_3.Name = "tbx4_3"
        Me.tbx4_3.Size = New System.Drawing.Size(29, 20)
        Me.tbx4_3.TabIndex = 41
        '
        'tbx3_3
        '
        Me.tbx3_3.Location = New System.Drawing.Point(263, 91)
        Me.tbx3_3.Name = "tbx3_3"
        Me.tbx3_3.Size = New System.Drawing.Size(29, 20)
        Me.tbx3_3.TabIndex = 40
        '
        'tbx2_3
        '
        Me.tbx2_3.Location = New System.Drawing.Point(263, 65)
        Me.tbx2_3.Name = "tbx2_3"
        Me.tbx2_3.Size = New System.Drawing.Size(29, 20)
        Me.tbx2_3.TabIndex = 39
        '
        'tbx6_4
        '
        Me.tbx6_4.Location = New System.Drawing.Point(298, 169)
        Me.tbx6_4.Name = "tbx6_4"
        Me.tbx6_4.Size = New System.Drawing.Size(29, 20)
        Me.tbx6_4.TabIndex = 48
        '
        'tbx5_4
        '
        Me.tbx5_4.Location = New System.Drawing.Point(298, 143)
        Me.tbx5_4.Name = "tbx5_4"
        Me.tbx5_4.Size = New System.Drawing.Size(29, 20)
        Me.tbx5_4.TabIndex = 47
        '
        'tbx4_4
        '
        Me.tbx4_4.Location = New System.Drawing.Point(298, 117)
        Me.tbx4_4.Name = "tbx4_4"
        Me.tbx4_4.Size = New System.Drawing.Size(29, 20)
        Me.tbx4_4.TabIndex = 46
        '
        'tbx3_4
        '
        Me.tbx3_4.Location = New System.Drawing.Point(298, 91)
        Me.tbx3_4.Name = "tbx3_4"
        Me.tbx3_4.Size = New System.Drawing.Size(29, 20)
        Me.tbx3_4.TabIndex = 45
        '
        'tbx2_4
        '
        Me.tbx2_4.Location = New System.Drawing.Point(298, 65)
        Me.tbx2_4.Name = "tbx2_4"
        Me.tbx2_4.Size = New System.Drawing.Size(29, 20)
        Me.tbx2_4.TabIndex = 44
        '
        'tbx6_5
        '
        Me.tbx6_5.Location = New System.Drawing.Point(333, 167)
        Me.tbx6_5.Name = "tbx6_5"
        Me.tbx6_5.Size = New System.Drawing.Size(29, 20)
        Me.tbx6_5.TabIndex = 53
        '
        'tbx5_5
        '
        Me.tbx5_5.Location = New System.Drawing.Point(333, 141)
        Me.tbx5_5.Name = "tbx5_5"
        Me.tbx5_5.Size = New System.Drawing.Size(29, 20)
        Me.tbx5_5.TabIndex = 52
        '
        'tbx4_5
        '
        Me.tbx4_5.Location = New System.Drawing.Point(333, 115)
        Me.tbx4_5.Name = "tbx4_5"
        Me.tbx4_5.Size = New System.Drawing.Size(29, 20)
        Me.tbx4_5.TabIndex = 51
        '
        'tbx3_5
        '
        Me.tbx3_5.Location = New System.Drawing.Point(333, 89)
        Me.tbx3_5.Name = "tbx3_5"
        Me.tbx3_5.Size = New System.Drawing.Size(29, 20)
        Me.tbx3_5.TabIndex = 50
        '
        'tbx2_5
        '
        Me.tbx2_5.Location = New System.Drawing.Point(333, 63)
        Me.tbx2_5.Name = "tbx2_5"
        Me.tbx2_5.Size = New System.Drawing.Size(29, 20)
        Me.tbx2_5.TabIndex = 49
        '
        'tbxn1
        '
        Me.tbxn1.Location = New System.Drawing.Point(10, 38)
        Me.tbxn1.Name = "tbxn1"
        Me.tbxn1.Size = New System.Drawing.Size(166, 20)
        Me.tbxn1.TabIndex = 54
        '
        'tbxn2
        '
        Me.tbxn2.Location = New System.Drawing.Point(10, 65)
        Me.tbxn2.Name = "tbxn2"
        Me.tbxn2.Size = New System.Drawing.Size(166, 20)
        Me.tbxn2.TabIndex = 55
        '
        'tbxn3
        '
        Me.tbxn3.Location = New System.Drawing.Point(10, 91)
        Me.tbxn3.Name = "tbxn3"
        Me.tbxn3.Size = New System.Drawing.Size(166, 20)
        Me.tbxn3.TabIndex = 56
        '
        'tbxn4
        '
        Me.tbxn4.Location = New System.Drawing.Point(10, 117)
        Me.tbxn4.Name = "tbxn4"
        Me.tbxn4.Size = New System.Drawing.Size(166, 20)
        Me.tbxn4.TabIndex = 57
        '
        'tbxn5
        '
        Me.tbxn5.Location = New System.Drawing.Point(10, 143)
        Me.tbxn5.Name = "tbxn5"
        Me.tbxn5.Size = New System.Drawing.Size(166, 20)
        Me.tbxn5.TabIndex = 58
        '
        'tbxn6
        '
        Me.tbxn6.Location = New System.Drawing.Point(10, 169)
        Me.tbxn6.Name = "tbxn6"
        Me.tbxn6.Size = New System.Drawing.Size(166, 20)
        Me.tbxn6.TabIndex = 59
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(365, 261)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(112, 23)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Calculate Average"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(534, 24)
        Me.MenuStrip1.TabIndex = 2
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PrintReportToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'PrintReportToolStripMenuItem
        '
        Me.PrintReportToolStripMenuItem.Name = "PrintReportToolStripMenuItem"
        Me.PrintReportToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.PrintReportToolStripMenuItem.Text = "Print Report"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(534, 296)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents tbxn6 As TextBox
    Friend WithEvents tbxn5 As TextBox
    Friend WithEvents tbxn4 As TextBox
    Friend WithEvents tbxn3 As TextBox
    Friend WithEvents tbxn2 As TextBox
    Friend WithEvents tbxn1 As TextBox
    Friend WithEvents tbx6_5 As TextBox
    Friend WithEvents tbx5_5 As TextBox
    Friend WithEvents tbx4_5 As TextBox
    Friend WithEvents tbx3_5 As TextBox
    Friend WithEvents tbx2_5 As TextBox
    Friend WithEvents tbx6_4 As TextBox
    Friend WithEvents tbx5_4 As TextBox
    Friend WithEvents tbx4_4 As TextBox
    Friend WithEvents tbx3_4 As TextBox
    Friend WithEvents tbx2_4 As TextBox
    Friend WithEvents tbx6_3 As TextBox
    Friend WithEvents tbx5_3 As TextBox
    Friend WithEvents tbx4_3 As TextBox
    Friend WithEvents tbx3_3 As TextBox
    Friend WithEvents tbx2_3 As TextBox
    Friend WithEvents tbx6_2 As TextBox
    Friend WithEvents tbx5_2 As TextBox
    Friend WithEvents tbx4_2 As TextBox
    Friend WithEvents tbx3_2 As TextBox
    Friend WithEvents tbx2_2 As TextBox
    Friend WithEvents tbx1_5 As TextBox
    Friend WithEvents tbx1_4 As TextBox
    Friend WithEvents tbx1_3 As TextBox
    Friend WithEvents tbx1_2 As TextBox
    Friend WithEvents tbx6_1 As TextBox
    Friend WithEvents tbx5_1 As TextBox
    Friend WithEvents tbx4_1 As TextBox
    Friend WithEvents tbx3_1 As TextBox
    Friend WithEvents tbx2_1 As TextBox
    Friend WithEvents tbx1_1 As TextBox
    Friend WithEvents lblav6 As Label
    Friend WithEvents lblav5 As Label
    Friend WithEvents lblav4 As Label
    Friend WithEvents lblav3 As Label
    Friend WithEvents lblav2 As Label
    Friend WithEvents lblav1 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PrintReportToolStripMenuItem As ToolStripMenuItem
End Class
